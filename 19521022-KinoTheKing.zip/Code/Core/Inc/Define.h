/*
 * Define.h
 *
 *  Created on: Nov 19, 2020
 *      Author: vanti
 */

#ifndef DEFINE_H_
#define DEFINE_H_

//#define VuongTrai 		1
//#define VuongPhai 		2
//#define ChuyenTrai	 	3
//#define ChuyenPhai 		4
//#define MatLine 		5
//#define VatCan 			6
//#define NgaBaTrai		7
//#define NgaBaPhai		8

#endif /* DEFINE_H_ */
